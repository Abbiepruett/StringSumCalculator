import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;


public class CalculatorGUI extends JFrame  {

   
    JTextField tfFirstNum, tfSecondNum,tfResult;
    
    public void initialize()

    {

       //create gridBagConstraints 
       GridBagConstraints gbc = null; 
       setLayout(new GridBagLayout());
       gbc = new GridBagConstraints();


        //form panel
        JLabel lbFirstNum = new JLabel("First Number");
        tfFirstNum = new JTextField(15);
        tfFirstNum.setEditable(true);
        
        JLabel lbSecondNum = new JLabel("Second Number");
        tfSecondNum = new JTextField(15);
        tfSecondNum.setEditable(true);

        JLabel lbResult = new JLabel("Result");
        tfResult = new JTextField(15);
        tfResult.setEditable(false);
       
        
        JButton btnEnter = new JButton("Enter");

        

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10,10,10,10);
        add(lbFirstNum, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        add(tfFirstNum, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 10, 10, 10);
        add(lbSecondNum, gbc);

        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.insets = new Insets(10,10,10,10);
        add(tfSecondNum,gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.insets = new Insets(10,10,10,10);
        add(btnEnter,gbc);

        JButton btnClear = new JButton("Clear");
        gbc.gridx = 1;
        gbc.gridy = 4;
        add(btnClear,gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.insets = new Insets(10,10,10,10);
        add(lbResult,gbc);

        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.insets = new Insets(10,10,10,10);
        add(tfResult,gbc);

      
       
        btnEnter.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                String firstNum = tfFirstNum.getText();
                String secondNum = tfSecondNum.getText();
                String myNum = Calc.calc(firstNum, secondNum);

                tfResult.setText(myNum);
                

                

            }
            
        });

        
        btnClear.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                tfFirstNum.setText("");
                tfSecondNum.setText("");
                tfResult.setText("");
            }
            
        });

        //panel that will contain the two buttons
        JPanel buttonsPanel = new JPanel();
    
        //add to main panel
        JPanel mainPanel = new JPanel();
        mainPanel.add(buttonsPanel);

        add(mainPanel);

        this.setSize(550,300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Calculator");
        this.setLocationRelativeTo(null);//center of screen
        this.setVisible(true);
        
     
}
}
