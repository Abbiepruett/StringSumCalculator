import java.awt.GridBagLayout;

/**
 * CalcViewer
 * execute the GUI by creating an instance of the class containing the GUI info
 */
public class CalcViewer {

    public static void main(String[] args) {
        CalculatorGUI gbl = new CalculatorGUI();
        gbl.initialize();
        
    }
}