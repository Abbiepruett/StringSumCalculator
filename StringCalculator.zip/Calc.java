public class Calc {
    
    /**
     * 
     * @param str1
     * @param str2
     */
    public static String calc(String str1, String str2){

        // Check if inputs are valid numbers
        if (!checkNums(str1) || !checkNums(str2)) {
            return "NAN";
        }

        // Make strings the same length by adding leading zeros
        int maxLength = Math.max(str1.length(), str2.length());
        str1 = addLeadingZeros(str1, maxLength);
        str2 = addLeadingZeros(str2, maxLength);

        int carry = 0;
        StringBuilder sum = new StringBuilder();

        // Loop through the strings from right to left
        for (int i = maxLength - 1; i >= 0; i--) {
            int digit1 = str1.charAt(i) - '0';
            int digit2 = str2.charAt(i) - '0';

            int currentSum = digit1 + digit2 + carry;
            carry = currentSum / 10;
            sum.insert(0, currentSum % 10); 
        }

        // If there's a carry after all digits are added, add it to the beginning of the sum
        if (carry != 0) {
            sum.insert(0, carry);
        }

        return sum.toString();
    }

    // Function to check if a string represents a valid number
    private static boolean checkNums(String str) {
        return str.matches("\\d+");
    }

    // Function to add leading zeros to make strings of equal length
    private static String addLeadingZeros(String str, int length) {
        int zerosToAdd = length - str.length();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < zerosToAdd; i++) {
            sb.append('0');
        }
        sb.append(str);
        return sb.toString();
    }//calc
}